package com.example.freevpn

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wireguard.android.backend.GoBackend
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.sin

enum class VpnState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

data class VpnServer(
    val id: String,
    val name: String,
    val countryCode: String,
    val region: String,
    val category: String,
    val flagEmoji: String,
    val endpointHost: String,
    val endpointPort: Int,
    val primaryDns: String,
    val secondaryDns: String,
    val pingMs: Int,
    val nodeIndex: Int = 0,
    val customWgConfig: String = ""
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00F2FE),
                    secondary = Color(0xFF8B5CF6),
                    tertiary = Color(0xFF10B981),
                    background = Color(0xFF05070D),
                    surface = Color(0xFF0E1322),
                    onBackground = Color(0xFFF9FAFB),
                    onSurface = Color(0xFFF3F4F6)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DarkVpnScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DarkVpnScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // 15 Country-Specific WireGuard Exit Nodes + Local WARP High-Speed Node
    val servers = remember {
        mutableStateListOf(
            VpnServer("us-ny-1", "United States (New York)", "US", "US East Exit IP • Node #1", "Americas", "🇺🇸", "us-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 42, 0),
            VpnServer("us-ca-2", "United States (Silicon Valley)", "US", "US West Exit IP • Node #2", "Americas", "🇺🇸", "us-exit-2.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 48, 1),
            VpnServer("us-fl-3", "United States (Miami Gaming)", "US", "US South Exit IP • Node #3", "Gaming", "🇺🇸", "us-exit-3.protonvpn.net", 51820, "8.8.8.8", "8.8.4.4", 45, 2),
            VpnServer("nl-ams-1", "Netherlands (Amsterdam #1)", "NL", "Dutch Exit IP • High-Speed Core", "Europe", "🇳🇱", "nl-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 34, 0),
            VpnServer("nl-ams-2", "Netherlands (Amsterdam #2)", "NL", "Dutch Exit IP • AdBlock Shield", "Europe", "🇳🇱", "nl-exit-2.protonvpn.net", 51820, "94.140.14.14", "94.140.15.15", 36, 1),
            VpnServer("jp-tyo-1", "Japan (Tokyo Core #1)", "JP", "Japanese Exit IP • Low-Ping Asia", "Asia", "🇯🇵", "jp-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 28, 0),
            VpnServer("jp-tyo-2", "Japan (Tokyo Gaming #2)", "JP", "Japanese Exit IP • Direct Route", "Gaming", "🇯🇵", "jp-exit-2.protonvpn.net", 51820, "1.0.0.1", "1.1.1.1", 29, 1),
            VpnServer("de-fra-1", "Germany (Frankfurt Core)", "DE", "German Exit IP • EU Backbone", "Europe", "🇩🇪", "de-exit-1.protonvpn.net", 51820, "9.9.9.9", "1.1.1.1", 35, 0),
            VpnServer("gb-lon-1", "United Kingdom (London)", "GB", "UK Exit IP • Streaming & Browsing", "Europe", "🇬🇧", "gb-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 37, 0),
            VpnServer("pl-waw-1", "Poland (Warsaw Core)", "PL", "Polish Exit IP • Fast EU Node", "Europe", "🇵🇱", "pl-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 38, 0),
            VpnServer("ro-otp-1", "Romania (Bucharest Vault)", "RO", "Romanian Exit IP • No-Log Privacy", "Europe", "🇷🇴", "ro-exit-1.protonvpn.net", 51820, "9.9.9.9", "149.112.112.112", 39, 0),
            VpnServer("ch-zrh-1", "Switzerland (Zurich Vault)", "CH", "Swiss Exit IP • Strict Privacy", "Europe", "🇨🇭", "ch-exit-1.protonvpn.net", 51820, "9.9.9.9", "1.1.1.1", 38, 0),
            VpnServer("fr-par-1", "France (Paris Core)", "FR", "French Exit IP • High-Speed EU", "Europe", "🇫🇷", "fr-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 39, 0),
            VpnServer("ca-tor-1", "Canada (Toronto Core)", "CA", "Canadian Exit IP • North America", "Americas", "🇨🇦", "ca-exit-1.protonvpn.net", 51820, "1.1.1.1", "1.0.0.1", 46, 0),
            VpnServer("warp-fast", "Cloudflare WARP+ (Nearest)", "WARP", "Ultra-Fast Local Colocation", "Asia", "⚡", "162.159.192.1", 2408, "1.1.1.1", "1.0.0.1", 10, 0)
        )
    }

    var selectedCategory by remember { mutableStateOf("All") }
    var selectedServer by remember { mutableStateOf(servers.first()) }
    var activeNodeOffset by remember { mutableIntStateOf(0) }
    var vpnState by remember { mutableStateOf(VpnState.DISCONNECTED) }
    var connectedSeconds by remember { mutableLongStateOf(0L) }
    var rxBytes by remember { mutableLongStateOf(0L) }
    var txBytes by remember { mutableLongStateOf(0L) }
    var rxSpeed by remember { mutableLongStateOf(0L) }
    var txSpeed by remember { mutableLongStateOf(0L) }
    var peakSpeedBps by remember { mutableLongStateOf(0L) }
    var publicIpDisplay by remember { mutableStateOf("Checking IP & Country...") }
    var errorBanner by remember { mutableStateOf("") }
    var isTestingSpeed by remember { mutableStateOf(false) }

    var showSettingsSheet by remember { mutableStateOf(false) }
    var showImportConfigDialog by remember { mutableStateOf(false) }

    // Fetch initial ISP IP & Country when disconnected
    LaunchedEffect(vpnState) {
        if (vpnState == VpnState.DISCONNECTED) {
            withContext(Dispatchers.IO) {
                try {
                    val conn = (URL("https://ipwho.is/").openConnection() as HttpURLConnection).apply {
                        connectTimeout = 3500
                        readTimeout = 3500
                    }
                    val body = conn.inputStream.bufferedReader().use { it.readText() }
                    conn.disconnect()
                    val json = JSONObject(body)
                    val ip = json.optString("ip", "")
                    val country = json.optString("country", "")
                    if (ip.isNotBlank()) {
                        publicIpDisplay = "$ip • $country (ISP Direct)"
                    }
                } catch (_: Exception) {
                    publicIpDisplay = "ISP Direct (Tap Orb to Switch Country)"
                }
            }
        }
    }

    // Listen to status updates broadcast from FreeVpnService
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    FreeVpnService.ACTION_STATUS_BROADCAST -> {
                        val stateStr = intent.getStringExtra(FreeVpnService.EXTRA_STATE)
                        vpnState = when (stateStr) {
                            "CONNECTED" -> VpnState.CONNECTED
                            "CONNECTING" -> VpnState.CONNECTING
                            else -> VpnState.DISCONNECTED
                        }
                        rxBytes = intent.getLongExtra(FreeVpnService.EXTRA_RX_BYTES, 0L)
                        txBytes = intent.getLongExtra(FreeVpnService.EXTRA_TX_BYTES, 0L)
                        rxSpeed = intent.getLongExtra(FreeVpnService.EXTRA_RX_SPEED, 0L)
                        txSpeed = intent.getLongExtra(FreeVpnService.EXTRA_TX_SPEED, 0L)
                        val ipExtra = intent.getStringExtra(FreeVpnService.EXTRA_PUBLIC_IP)
                        if (!ipExtra.isNullOrBlank()) {
                            publicIpDisplay = ipExtra
                        }
                        val errExtra = intent.getStringExtra(FreeVpnService.EXTRA_ERROR_MSG)
                        if (!errExtra.isNullOrBlank()) {
                            errorBanner = errExtra
                        }
                        if (rxSpeed + txSpeed > peakSpeedBps) {
                            peakSpeedBps = rxSpeed + txSpeed
                        }
                    }
                }
            }
        }
        val filter = IntentFilter(FreeVpnService.ACTION_STATUS_BROADCAST)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            context.registerReceiver(receiver, filter)
        }
        onDispose {
            context.unregisterReceiver(receiver)
        }
    }

    // Session timer while connected
    LaunchedEffect(vpnState) {
        if (vpnState == VpnState.CONNECTED) {
            errorBanner = ""
            while (vpnState == VpnState.CONNECTED) {
                delay(1000L)
                connectedSeconds += 1L
            }
        } else if (vpnState == VpnState.DISCONNECTED) {
            connectedSeconds = 0L
            rxBytes = 0L
            txBytes = 0L
            rxSpeed = 0L
            txSpeed = 0L
            peakSpeedBps = 0L
        }
    }

    fun startVpnService(server: VpnServer, extraOffset: Int = activeNodeOffset) {
        vpnState = VpnState.CONNECTING
        errorBanner = ""
        val serviceIntent = Intent(context, FreeVpnService::class.java).apply {
            action = FreeVpnService.ACTION_CONNECT
            putExtra(FreeVpnService.EXTRA_SERVER_NAME, server.name)
            putExtra(FreeVpnService.EXTRA_COUNTRY_CODE, server.countryCode)
            putExtra(FreeVpnService.EXTRA_NODE_INDEX, server.nodeIndex + extraOffset)
            putExtra(FreeVpnService.EXTRA_ENDPOINT_HOST, server.endpointHost)
            putExtra(FreeVpnService.EXTRA_ENDPOINT_PORT, server.endpointPort)
            putExtra(FreeVpnService.EXTRA_DNS_SERVER, server.primaryDns)
            putExtra(FreeVpnService.EXTRA_SECONDARY_DNS, server.secondaryDns)
            putExtra(FreeVpnService.EXTRA_CUSTOM_WG_CONF, server.customWgConfig)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }

    fun stopVpnService() {
        val serviceIntent = Intent(context, FreeVpnService::class.java).apply {
            action = FreeVpnService.ACTION_DISCONNECT
        }
        context.startService(serviceIntent)
        vpnState = VpnState.DISCONNECTED
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            startVpnService(selectedServer)
        } else {
            vpnState = VpnState.DISCONNECTED
        }
    }

    fun onToggleVpn() {
        if (vpnState == VpnState.CONNECTED || vpnState == VpnState.CONNECTING) {
            stopVpnService()
        } else {
            val prepareIntent = GoBackend.VpnService.prepare(context)
            if (prepareIntent != null) {
                vpnPermissionLauncher.launch(prepareIntent)
            } else {
                startVpnService(selectedServer)
            }
        }
    }

    fun rotateCountryNode() {
        activeNodeOffset += 1
        startVpnService(selectedServer, activeNodeOffset)
    }

    fun runLiveSpeedBenchmark() {
        if (isTestingSpeed) return
        isTestingSpeed = true
        scope.launch {
            withContext(Dispatchers.IO) {
                try {
                    val testUrls = listOf(
                        "https://speed.cloudflare.com/__down?bytes=5000000",
                        "https://proof.ovh.net/files/1Mb.dat"
                    )
                    for (urlStr in testUrls) {
                        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3000
                            readTimeout = 4000
                            setRequestProperty("User-Agent", "DarkVPN-SpeedBenchmark/4.0")
                        }
                        val buffer = ByteArray(16384)
                        conn.inputStream.use { input ->
                            val startMs = System.currentTimeMillis()
                            while (input.read(buffer) != -1) {
                                if (System.currentTimeMillis() - startMs > 3500) break
                            }
                        }
                        conn.disconnect()
                        break
                    }
                } catch (_: Exception) {
                }
            }
            isTestingSpeed = false
        }
    }

    val filteredServers = remember(selectedCategory, servers.size, servers.toList()) {
        if (selectedCategory == "All") servers
        else servers.filter { it.category == selectedCategory }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(Color(0xFF00F2FE), Color(0xFF8B5CF6))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Dark VPN",
                                tint = Color(0xFF05070D),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DARK VPN",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                letterSpacing = 1.5.sp,
                                color = Color.White
                            )
                            Text(
                                text = "MULTI-COUNTRY WIREGUARD EXIT CORE",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.0.sp,
                                color = Color(0xFF00F2FE)
                            )
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { rotateCountryNode() }) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Rotate Country IP",
                            tint = Color(0xFF00F2FE)
                        )
                    }
                    IconButton(onClick = { showImportConfigDialog = true }) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Import Custom WireGuard Config"
                        )
                    }
                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF05070D),
                    titleContentColor = Color.White,
                    actionIconContentColor = Color(0xFF9CA3AF)
                )
            )
        },
        containerColor = Color(0xFF05070D)
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))
                StatusBadge(
                    vpnState = vpnState,
                    publicIpText = publicIpDisplay
                )
                if (errorBanner.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorBanner,
                        fontSize = 11.sp,
                        color = Color(0xFFF87171)
                    )
                }
                Spacer(modifier = Modifier.height(14.dp))
            }

            // Animated Speedometer Gauge + Connect Dashboard Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(24.dp))
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF11182B), Color(0xFF0A0E1A))
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF00F2FE).copy(alpha = 0.45f),
                                    Color(0xFF8B5CF6).copy(alpha = 0.25f)
                                )
                            ),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        SpeedometerGauge(
                            bytesPerSec = rxSpeed + txSpeed,
                            pingMs = selectedServer.pingMs,
                            isConnected = vpnState == VpnState.CONNECTED
                        )

                        CyberConnectOrb(
                            vpnState = vpnState,
                            countryFlag = selectedServer.flagEmoji,
                            durationText = formatDuration(connectedSeconds),
                            onClick = { onToggleVpn() }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        TelemetryCard(
                            label = "DOWNLOAD",
                            speedValue = formatSpeed(rxSpeed),
                            totalValue = formatBytes(rxBytes),
                            accentColor = Color(0xFF00F2FE),
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryCard(
                            label = "UPLOAD",
                            speedValue = formatSpeed(txSpeed),
                            totalValue = formatBytes(txBytes),
                            accentColor = Color(0xFF8B5CF6),
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryCard(
                            label = "TARGET REGION",
                            speedValue = "${selectedServer.flagEmoji} ${selectedServer.countryCode}",
                            totalValue = "Node #${(selectedServer.nodeIndex + activeNodeOffset) % 10 + 1}",
                            accentColor = Color(0xFF10B981),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { runLiveSpeedBenchmark() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF19223B),
                                contentColor = Color(0xFF00F2FE)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = if (isTestingSpeed) "TESTING SPEED..." else "⚡ SPEED TEST",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { rotateCountryNode() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF19223B),
                                contentColor = Color(0xFF10B981)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "🔄 SWITCH ${selectedServer.countryCode} IP",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))
            }

            // Category Filter Tabs
            item {
                val categories = listOf("All", "Americas", "Europe", "Asia", "Gaming")
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val active = selectedCategory == cat
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .background(
                                    if (active) Brush.horizontalGradient(
                                        listOf(Color(0xFF00F2FE), Color(0xFF8B5CF6))
                                    )
                                    else Brush.horizontalGradient(
                                        listOf(Color(0xFF11182B), Color(0xFF11182B))
                                    )
                                )
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 16.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = if (cat == "All") "All Countries (${servers.size})" else cat,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (active) Color(0xFF05070D) else Color(0xFF9CA3AF)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Server List Items
            items(filteredServers, key = { it.id }) { server ->
                ServerRowItem(
                    server = server,
                    isSelected = server.id == selectedServer.id,
                    onSelect = {
                        val wasConnected = vpnState == VpnState.CONNECTED
                        selectedServer = server
                        activeNodeOffset = 0
                        if (wasConnected) {
                            startVpnService(server, 0)
                        }
                    }
                )
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }

    if (showSettingsSheet) {
        AlertDialog(
            onDismissRequest = { showSettingsSheet = false },
            containerColor = Color(0xFF0E1322),
            title = {
                Text("Country Exit IP Guide", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "• Country-Specific Servers (US, NL, JP, DE, GB, PL, RO, CH, FR, CA): Uses physical WireGuard exit nodes located in that country so websites like whatismyipaddress.com detect that exact country.",
                        color = Color(0xFFD1D5DB),
                        fontSize = 13.sp
                    )
                    Text(
                        text = "• Switch IP Button: If a free public country server is busy, tap '🔄 SWITCH IP' to rotate to the next WireGuard node in that country.",
                        color = Color(0xFF9CA3AF),
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showSettingsSheet = false }) {
                    Text("Close", color = Color(0xFF00F2FE))
                }
            }
        )
    }

    if (showImportConfigDialog) {
        var nameInput by remember { mutableStateOf("") }
        var countryCodeInput by remember { mutableStateOf("US") }
        var wgConfInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showImportConfigDialog = false },
            containerColor = Color(0xFF0E1322),
            title = {
                Text("Import Custom Country WireGuard .conf", color = Color.White, fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        label = { Text("Server Label (e.g. USA Dedicated)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = countryCodeInput,
                        onValueChange = { countryCodeInput = it },
                        label = { Text("2-Letter Country Code (e.g. US, GB, JP)") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = wgConfInput,
                        onValueChange = { wgConfInput = it },
                        label = { Text("Paste [Interface] & [Peer] .conf") },
                        minLines = 5,
                        maxLines = 8
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (nameInput.isNotBlank() && wgConfInput.contains("[Interface]") && wgConfInput.contains("[Peer]")) {
                            val cc = countryCodeInput.trim().uppercase().take(2).ifBlank { "US" }
                            val newServer = VpnServer(
                                id = "custom-${System.currentTimeMillis()}",
                                name = nameInput.trim(),
                                countryCode = cc,
                                region = "Custom $cc WireGuard Exit",
                                category = "Americas",
                                flagEmoji = "🌐",
                                endpointHost = "Custom .conf",
                                endpointPort = 51820,
                                primaryDns = "1.1.1.1",
                                secondaryDns = "1.0.0.1",
                                pingMs = 20,
                                customWgConfig = wgConfInput.trim()
                            )
                            servers.add(0, newServer)
                            selectedServer = newServer
                            showImportConfigDialog = false
                        }
                    }
                ) {
                    Text("Import & Connect", color = Color(0xFF00F2FE))
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportConfigDialog = false }) {
                    Text("Cancel", color = Color(0xFF9CA3AF))
                }
            }
        )
    }
}

@Composable
fun SpeedometerGauge(
    bytesPerSec: Long,
    pingMs: Int,
    isConnected: Boolean
) {
    val mbps = (bytesPerSec * 8.0) / 1_000_000.0
    val targetFraction = if (!isConnected && bytesPerSec == 0L) {
        0f
    } else {
        val logVal = (ln(1.0 + mbps * 12.0) / ln(1.0 + 100.0 * 12.0)).toFloat()
        logVal.coerceIn(0.03f, 1f)
    }

    val animatedFraction by animateFloatAsState(
        targetValue = targetFraction,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "speedNeedle"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(165.dp)
    ) {
        Canvas(modifier = Modifier.size(155.dp)) {
            val strokeWidth = 13.dp.toPx()
            val arcSize = Size(size.width - strokeWidth, size.height - strokeWidth)
            val topLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)

            drawArc(
                color = Color(0xFF1E293B),
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val center = Offset(size.width / 2f, size.height / 2f)
            val outerRadius = (size.width - strokeWidth) / 2f - 10.dp.toPx()
            for (i in 0..24) {
                val angleDeg = 150f + (i * 10f)
                val rad = Math.toRadians(angleDeg.toDouble())
                val isMajor = i % 4 == 0
                val innerR = outerRadius - if (isMajor) 8.dp.toPx() else 4.dp.toPx()
                val startPt = Offset(
                    x = center.x + (innerR * cos(rad)).toFloat(),
                    y = center.y + (innerR * sin(rad)).toFloat()
                )
                val endPt = Offset(
                    x = center.x + (outerRadius * cos(rad)).toFloat(),
                    y = center.y + (outerRadius * sin(rad)).toFloat()
                )
                drawLine(
                    color = if (i / 24f <= animatedFraction) Color(0xFF00F2FE) else Color(0xFF475569),
                    start = startPt,
                    end = endPt,
                    strokeWidth = if (isMajor) 2.2.dp.toPx() else 1.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }

            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(
                        Color(0xFF00F2FE),
                        Color(0xFF8B5CF6),
                        Color(0xFF10B981),
                        Color(0xFF00F2FE)
                    )
                ),
                startAngle = 150f,
                sweepAngle = (240f * animatedFraction).coerceAtLeast(4f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            val needleAngleDeg = 150f + 240f * animatedFraction
            val needleRad = Math.toRadians(needleAngleDeg.toDouble())
            val needleLength = outerRadius - 6.dp.toPx()
            val needleTip = Offset(
                x = center.x + (needleLength * cos(needleRad)).toFloat(),
                y = center.y + (needleLength * sin(needleRad)).toFloat()
            )
            drawLine(
                color = Color(0xFF00F2FE),
                start = center,
                end = needleTip,
                strokeWidth = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(
                color = Color(0xFF8B5CF6),
                radius = 6.dp.toPx(),
                center = center
            )
            drawCircle(
                color = Color.White,
                radius = 2.5.dp.toPx(),
                center = center
            )
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 56.dp)
        ) {
            Text(
                text = String.format("%.2f", mbps),
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                fontFamily = FontFamily.Monospace,
                color = Color.White
            )
            Text(
                text = "Mbps • ${pingMs}ms",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F2FE)
            )
        }
    }
}

@Composable
fun CyberConnectOrb(
    vpnState: VpnState,
    countryFlag: String,
    durationText: String,
    onClick: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(3200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = if (vpnState != VpnState.DISCONNECTED) 1.08f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryGlow by animateColorAsState(
        targetValue = when (vpnState) {
            VpnState.CONNECTED -> Color(0xFF00F2FE)
            VpnState.CONNECTING -> Color(0xFFF59E0B)
            VpnState.DISCONNECTED -> Color(0xFF475569)
        },
        label = "glow"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(150.dp)
    ) {
        Box(
            modifier = Modifier
                .size(144.dp)
                .scale(pulseScale)
                .clip(CircleShape)
                .background(primaryGlow.copy(alpha = 0.14f))
        )

        Box(
            modifier = Modifier
                .size(130.dp)
                .rotate(if (vpnState != VpnState.DISCONNECTED) rotation else 0f)
                .clip(CircleShape)
                .border(
                    width = 3.dp,
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            primaryGlow,
                            Color(0xFF8B5CF6),
                            primaryGlow.copy(alpha = 0.2f),
                            primaryGlow
                        )
                    ),
                    shape = CircleShape
                )
        )

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(116.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1B243B), Color(0xFF090D18))
                    )
                )
                .clickable { onClick() }
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(text = countryFlag, fontSize = 26.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = when (vpnState) {
                        VpnState.CONNECTED -> "CONNECTED"
                        VpnState.CONNECTING -> "ROUTING..."
                        VpnState.DISCONNECTED -> "TAP TO LINK"
                    },
                    fontSize = 11.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 0.8.sp
                )
                Text(
                    text = durationText,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    color = primaryGlow
                )
            }
        }
    }
}

@Composable
fun StatusBadge(vpnState: VpnState, publicIpText: String) {
    val bgColor = when (vpnState) {
        VpnState.CONNECTED -> Color(0xFF062C30)
        VpnState.CONNECTING -> Color(0xFF3B2106)
        VpnState.DISCONNECTED -> Color(0xFF141B2D)
    }
    val dotColor = when (vpnState) {
        VpnState.CONNECTED -> Color(0xFF00F2FE)
        VpnState.CONNECTING -> Color(0xFFF59E0B)
        VpnState.DISCONNECTED -> Color(0xFFEF4444)
    }
    val text = when (vpnState) {
        VpnState.CONNECTED -> "EXIT IP: $publicIpText"
        VpnState.CONNECTING -> "SWITCHING EXIT COUNTRY..."
        VpnState.DISCONNECTED -> "CURRENT IP: $publicIpText"
    }

    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(bgColor)
            .border(1.dp, dotColor.copy(alpha = 0.4f), RoundedCornerShape(50))
            .padding(horizontal = 14.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(dotColor)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun TelemetryCard(
    label: String,
    speedValue: String,
    totalValue: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF090D18))
            .border(1.dp, accentColor.copy(alpha = 0.22f), RoundedCornerShape(14.dp))
            .padding(10.dp)
    ) {
        Text(
            text = label,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF9CA3AF),
            letterSpacing = 0.7.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = speedValue,
            fontSize = 13.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace,
            color = accentColor
        )
        Text(
            text = totalValue,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            color = Color(0xFF64748B)
        )
    }
}

@Composable
fun ServerRowItem(
    server: VpnServer,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    val borderBrush = if (isSelected) {
        Brush.horizontalGradient(listOf(Color(0xFF00F2FE), Color(0xFF8B5CF6)))
    } else {
        Brush.horizontalGradient(listOf(Color(0xFF1E293B), Color(0xFF1E293B)))
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) Color(0xFF141D33) else Color(0xFF0E1322))
            .border(1.5.dp, borderBrush, RoundedCornerShape(16.dp))
            .clickable { onSelect() }
            .padding(horizontal = 16.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Text(text = server.flagEmoji, fontSize = 24.sp)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = server.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF1E293B))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = server.countryCode,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00F2FE)
                        )
                    }
                }
                Text(
                    text = server.region,
                    fontSize = 11.sp,
                    color = Color(0xFF9CA3AF)
                )
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            val pingColor = when {
                server.pingMs <= 30 -> Color(0xFF10B981)
                server.pingMs <= 50 -> Color(0xFF00F2FE)
                else -> Color(0xFFF59E0B)
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(pingColor.copy(alpha = 0.14f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${server.pingMs} ms",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = pingColor
                )
            }
            if (isSelected) {
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = Color(0xFF00F2FE),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

private fun formatDuration(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return String.format("%02d:%02d:%02d", hrs, mins, secs)
}

private fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec < 1024) return "$bytesPerSec B/s"
    val kb = bytesPerSec / 1024.0
    if (kb < 1024) return String.format("%.1f KB/s", kb)
    val mb = kb / 1024.0
    return String.format("%.2f MB/s", mb)
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.2f MB", mb)
    val gb = mb / 1024.0
    return String.format("%.2f GB", gb)
}
