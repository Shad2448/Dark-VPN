package com.example.freevpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.TrafficStats
import android.net.VpnService
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.ByteArrayInputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.util.concurrent.atomic.AtomicBoolean
import java.util.zip.ZipInputStream

/**
 * Dark VPN Service — Country-Specific WireGuard (`GoBackend`) Tunnel Engine.
 *
 * Why Cloudflare WARP showed Bangladesh (104.28.x.x):
 * Cloudflare WARP uses Anycast and geo-tags its 104.28.x.x exit pool to the user's home country.
 *
 * To actually change the exit country (USA, Netherlands, Japan, Germany, UK, Canada, France,
 * Switzerland, Poland, Romania), this service:
 * 1. Checks bundled `assets/wg_configs/<COUNTRY_CODE>/` baked in at build time by GitHub Actions.
 * 2. Downloads live country-specific WireGuard `.conf` pools from public GitHub WireGuard
 *    repositories (`ProtonVPN_WireGuard_Configs.zip` / country `.conf` feeds) and caches them.
 * 3. Supports rotating across multiple server nodes per country (`nodeIndex`) so if one public
 *    node is busy, tapping "Rotate IP" switches to a fresh exit IP in that country.
 */
class FreeVpnService : VpnService() {

    companion object {
        private const val TAG = "DarkVpnService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "dark_vpn_channel"
        private const val PREFS_NAME = "dark_vpn_country_prefs"

        const val ACTION_CONNECT = "com.example.freevpn.ACTION_CONNECT"
        const val ACTION_DISCONNECT = "com.example.freevpn.ACTION_DISCONNECT"
        const val ACTION_STATUS_BROADCAST = "com.example.freevpn.ACTION_STATUS_BROADCAST"

        const val EXTRA_SERVER_NAME = "extra_server_name"
        const val EXTRA_COUNTRY_CODE = "extra_country_code"
        const val EXTRA_NODE_INDEX = "extra_node_index"
        const val EXTRA_ENDPOINT_HOST = "extra_endpoint_host"
        const val EXTRA_ENDPOINT_PORT = "extra_endpoint_port"
        const val EXTRA_DNS_SERVER = "extra_dns_server"
        const val EXTRA_SECONDARY_DNS = "extra_secondary_dns"
        const val EXTRA_CUSTOM_WG_CONF = "extra_custom_wg_conf"

        const val EXTRA_STATE = "extra_state"
        const val EXTRA_RX_BYTES = "extra_rx_bytes"
        const val EXTRA_TX_BYTES = "extra_tx_bytes"
        const val EXTRA_RX_SPEED = "extra_rx_speed"
        const val EXTRA_TX_SPEED = "extra_tx_speed"
        const val EXTRA_PUBLIC_IP = "extra_public_ip"
        const val EXTRA_ERROR_MSG = "extra_error_msg"

        @Volatile
        private var sharedBackend: GoBackend? = null

        // In-memory cache of countryCode -> list of WireGuard .conf strings
        private val countryConfigsCache = mutableMapOf<String, MutableList<String>>()

        private val wgTunnel = object : Tunnel {
            override fun getName(): String = "darkvpn0"
            override fun onStateChange(newState: Tunnel.State) {
                Log.i(TAG, "WireGuard tunnel state changed: $newState")
            }
        }
    }

    private val isRunning = AtomicBoolean(false)
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tunnelJob: Job? = null
    private var telemetryJob: Job? = null
    private var currentPublicIp: String = "Switching Country IP..."

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val serverName = intent.getStringExtra(EXTRA_SERVER_NAME) ?: "United States"
                val countryCode = intent.getStringExtra(EXTRA_COUNTRY_CODE) ?: "US"
                val nodeIndex = intent.getIntExtra(EXTRA_NODE_INDEX, 0)
                val endpointHost = intent.getStringExtra(EXTRA_ENDPOINT_HOST) ?: "162.159.192.1"
                val endpointPort = intent.getIntExtra(EXTRA_ENDPOINT_PORT, 2408)
                val dnsServer = intent.getStringExtra(EXTRA_DNS_SERVER) ?: "1.1.1.1"
                val secondaryDns = intent.getStringExtra(EXTRA_SECONDARY_DNS) ?: "1.0.0.1"
                val customWgConf = intent.getStringExtra(EXTRA_CUSTOM_WG_CONF) ?: ""

                startWireGuardTunnel(
                    serverName = serverName,
                    countryCode = countryCode.uppercase(),
                    nodeIndex = nodeIndex,
                    endpointHost = endpointHost,
                    endpointPort = endpointPort,
                    dnsServer = dnsServer,
                    secondaryDns = secondaryDns,
                    customWgConf = customWgConf
                )
            }
            ACTION_DISCONNECT -> {
                stopWireGuardTunnel()
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun getOrInitBackend(): GoBackend {
        val existing = sharedBackend
        if (existing != null) return existing
        val created = GoBackend(applicationContext)
        sharedBackend = created
        return created
    }

    private fun startWireGuardTunnel(
        serverName: String,
        countryCode: String,
        nodeIndex: Int,
        endpointHost: String,
        endpointPort: Int,
        dnsServer: String,
        secondaryDns: String,
        customWgConf: String
    ) {
        if (isRunning.getAndSet(true)) {
            stopWireGuardTunnel()
            isRunning.set(true)
        }

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Routing to $serverName ($countryCode)..."))
        broadcastState("CONNECTING", 0L, 0L, 0L, 0L, "Connecting to $countryCode Exit Node...", "")

        tunnelJob = serviceScope.launch {
            try {
                val backend = getOrInitBackend()

                // Bring down any existing tunnel before fetching new country config so network is direct
                try {
                    backend.setState(wgTunnel, Tunnel.State.DOWN, null)
                } catch (_: Exception) {
                }

                // 1. Resolve the WireGuard configuration for the requested country
                val wgConfigText = when {
                    customWgConf.isNotBlank() -> customWgConf.trim()
                    countryCode == "WARP" -> getOrRegisterWarpConfig(
                        endpointHost = endpointHost,
                        endpointPort = endpointPort,
                        dnsServer = dnsServer,
                        secondaryDns = secondaryDns
                    )
                    else -> resolveCountryWireGuardConfig(
                        countryCode = countryCode,
                        nodeIndex = nodeIndex,
                        fallbackEndpointHost = endpointHost,
                        fallbackEndpointPort = endpointPort,
                        dnsServer = dnsServer,
                        secondaryDns = secondaryDns
                    )
                }

                val sanitizedConf = sanitizeWireGuardConfig(wgConfigText, dnsServer)
                val config = Config.parse(
                    ByteArrayInputStream(sanitizedConf.toByteArray(StandardCharsets.UTF_8))
                )

                backend.setState(wgTunnel, Tunnel.State.UP, config)

                currentPublicIp = "Verifying $countryCode Exit IP..."
                updateNotification("Dark VPN • Connected to $serverName")
                broadcastState("CONNECTED", 0L, 0L, 0L, 0L, currentPublicIp, "")

                startTelemetryLoop(serverName)

                // Verify the new exit IP and country location after tunnel settles
                delay(2000L)
                val verifiedIpAndCountry = fetchCurrentExitIpAndCountry(countryCode)
                currentPublicIp = verifiedIpAndCountry
            } catch (e: CancellationException) {
                Log.i(TAG, "WireGuard tunnel job cancelled")
            } catch (e: Exception) {
                Log.e(TAG, "WireGuard tunnel error: ${e.message}", e)
                broadcastState(
                    "DISCONNECTED",
                    0L,
                    0L,
                    0L,
                    0L,
                    "Connection Failed",
                    e.localizedMessage ?: "WireGuard handshake error"
                )
                stopWireGuardTunnel()
            }
        }
    }

    /**
     * Resolves a real country-specific WireGuard .conf for [countryCode] (e.g., US, NL, JP, DE, GB, FR, CA, CH, PL, RO).
     * 1. Checks APK bundled assets (`assets/wg_configs/<CC>/`) populated during the GitHub Actions build.
     * 2. Downloads & caches live country configs from public GitHub WireGuard repositories if not yet cached.
     */
    private fun resolveCountryWireGuardConfig(
        countryCode: String,
        nodeIndex: Int,
        fallbackEndpointHost: String,
        fallbackEndpointPort: Int,
        dnsServer: String,
        secondaryDns: String
    ): String {
        // Step 1: Load from APK bundled assets if available
        synchronized(countryConfigsCache) {
            if (countryConfigsCache[countryCode].isNullOrEmpty()) {
                loadBundledAssetConfigsIntoCache()
            }
        }

        // Step 2: If still empty for this country, download live country .conf archive from GitHub
        val existingList = synchronized(countryConfigsCache) { countryConfigsCache[countryCode] }
        if (existingList.isNullOrEmpty()) {
            fetchLiveCountryConfigsFromGitHub()
        }

        val configsForCountry = synchronized(countryConfigsCache) {
            countryConfigsCache[countryCode]
                ?: countryConfigsCache.entries.firstOrNull { it.key.startsWith(countryCode.take(2)) }?.value
                ?: countryConfigsCache["US"]
        }

        if (!configsForCountry.isNullOrEmpty()) {
            val pickIdx = (nodeIndex.coerceAtLeast(0)) % configsForCountry.size
            return configsForCountry[pickIdx]
        }

        // Fallback if GitHub raw archive is unreachable on user's ISP
        return getOrRegisterWarpConfig(
            endpointHost = fallbackEndpointHost,
            endpointPort = fallbackEndpointPort,
            dnsServer = dnsServer,
            secondaryDns = secondaryDns
        )
    }

    private fun loadBundledAssetConfigsIntoCache() {
        try {
            val assetManager = assets
            val countryDirs = assetManager.list("wg_configs") ?: return
            for (cc in countryDirs) {
                val files = assetManager.list("wg_configs/$cc") ?: continue
                val list = countryConfigsCache.getOrPut(cc.uppercase()) { mutableListOf() }
                for (fileName in files) {
                    if (fileName.endsWith(".conf")) {
                        val content = assetManager.open("wg_configs/$cc/$fileName")
                            .bufferedReader(StandardCharsets.UTF_8)
                            .use { it.readText() }
                        if (content.contains("[Interface]") && content.contains("[Peer]")) {
                            list.add(content)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "No bundled wg_configs assets or error reading: ${e.message}")
        }
    }

    private fun fetchLiveCountryConfigsFromGitHub() {
        val zipUrls = listOf(
            "https://raw.githubusercontent.com/Delta-Kronecker/ProtonVPN-WireGuard-configuration/main/ProtonVPN_WireGuard_Configs.zip",
            "https://github.com/Delta-Kronecker/ProtonVPN-WireGuard-configuration/raw/refs/heads/main/ProtonVPN_WireGuard_Configs.zip"
        )
        for (urlStr in zipUrls) {
            try {
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 8000
                    readTimeout = 10000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "DarkVPN-ConfigSync/4.0")
                }
                if (conn.responseCode in 200..299) {
                    ZipInputStream(conn.inputStream).use { zis ->
                        var entry = zis.nextEntry
                        while (entry != null) {
                            val name = entry.name
                            if (!entry.isDirectory && name.endsWith(".conf", ignoreCase = true)) {
                                val text = zis.bufferedReader(StandardCharsets.UTF_8).readText()
                                if (text.contains("[Interface]") && text.contains("[Peer]")) {
                                    val cc = extractCountryCodeFromPath(name)
                                    synchronized(countryConfigsCache) {
                                        val list = countryConfigsCache.getOrPut(cc) { mutableListOf() }
                                        if (list.size < 25) {
                                            list.add(text)
                                        }
                                    }
                                }
                            }
                            zis.closeEntry()
                            entry = zis.nextEntry
                        }
                    }
                    conn.disconnect()
                    return
                }
                conn.disconnect()
            } catch (e: Exception) {
                Log.w(TAG, "Live GitHub config zip sync failed on $urlStr: ${e.message}")
            }
        }
    }

    private fun extractCountryCodeFromPath(entryName: String): String {
        val parts = entryName.split("/", "\\")
        if (parts.size >= 2 && parts[0].length == 2) {
            return parts[0].uppercase()
        }
        val base = parts.last().uppercase()
        val regex = Regex("^([A-Z]{2})[-_#]")
        val match = regex.find(base)
        if (match != null) {
            return match.groupValues[1]
        }
        return "US"
    }

    /**
     * Cleans any non-standard wg-quick directives and ensures MTU = 1280 and IPv4 AllowedIPs
     * so Android's GoBackend parses every config cleanly without IPv6 leak or MTU stall.
     */
    private fun sanitizeWireGuardConfig(rawConf: String, fallbackDns: String): String {
        val sb = StringBuilder()
        var hasMtu = false
        for (rawLine in rawConf.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#")) continue
            val lower = line.lowercase()
            // Strip desktop-only wg-quick hooks not supported by Android GoBackend
            if (lower.startsWith("postup") ||
                lower.startsWith("postdown") ||
                lower.startsWith("preup") ||
                lower.startsWith("predown") ||
                lower.startsWith("table") ||
                lower.startsWith("saveconfig")
            ) {
                continue
            }
            if (lower.startsWith("mtu")) {
                hasMtu = true
                sb.appendLine("MTU = 1280")
            } else if (lower.startsWith("address")) {
                // Keep only IPv4 CIDR if dual-stack address fails on IPv4-only mobile carriers
                val rhs = line.substringAfter("=").trim()
                val ipv4Part = rhs.split(",")
                    .map { it.trim() }
                    .firstOrNull { !it.contains(":") }
                    ?: rhs
                sb.appendLine("Address = $ipv4Part")
            } else if (lower.startsWith("dns")) {
                val rhs = line.substringAfter("=").trim()
                val ipv4Dns = rhs.split(",")
                    .map { it.trim() }
                    .filter { !it.contains(":") }
                if (ipv4Dns.isNotEmpty()) {
                    sb.appendLine("DNS = ${ipv4Dns.joinToString(", ")}")
                } else {
                    sb.appendLine("DNS = $fallbackDns")
                }
            } else if (lower.startsWith("allowedips")) {
                sb.appendLine("AllowedIPs = 0.0.0.0/0")
            } else {
                sb.appendLine(line)
            }
            if (line.equals("[Interface]", ignoreCase = true) && !hasMtu) {
                sb.appendLine("MTU = 1280")
                hasMtu = true
            }
        }
        return sb.toString()
    }

    private fun getOrRegisterWarpConfig(
        endpointHost: String,
        endpointPort: Int,
        dnsServer: String,
        secondaryDns: String
    ): String {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        var privKey = prefs.getString("wg_private_key", null)
        var v4Address = prefs.getString("wg_v4_address", null)
        var peerPubKey = prefs.getString("wg_peer_public_key", null)

        if (privKey.isNullOrBlank() || v4Address.isNullOrBlank() || peerPubKey.isNullOrBlank()) {
            val keyPair = KeyPair()
            val generatedPriv = keyPair.privateKey.toBase64()
            val generatedPub = keyPair.publicKey.toBase64()

            val regResult = registerWithCloudflareWarpApi(generatedPub)
            privKey = generatedPriv
            v4Address = regResult.first
            peerPubKey = regResult.second

            prefs.edit()
                .putString("wg_private_key", privKey)
                .putString("wg_v4_address", v4Address)
                .putString("wg_peer_public_key", peerPubKey)
                .apply()
        }

        return """
            [Interface]
            PrivateKey = $privKey
            Address = $v4Address/32
            DNS = $dnsServer, $secondaryDns
            MTU = 1280

            [Peer]
            PublicKey = $peerPubKey
            AllowedIPs = 0.0.0.0/0
            Endpoint = $endpointHost:$endpointPort
            PersistentKeepalive = 25
        """.trimIndent()
    }

    private fun registerWithCloudflareWarpApi(publicKeyBase64: String): Pair<String, String> {
        val defaultPeerKey = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
        val endpoints = listOf(
            "https://api.cloudflareclient.com/v0a2158/reg",
            "https://api.cloudflareclient.com/v0a737/reg"
        )
        val payload = JSONObject().apply {
            put("key", publicKeyBase64)
            put("install_id", "")
            put("warp_enabled", true)
            put("tos", "2023-11-11T00:00:00.000Z")
            put("type", "Android")
            put("locale", "en_US")
        }.toString()

        for (urlStr in endpoints) {
            try {
                val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 6000
                    readTimeout = 6000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "okhttp/3.12.1")
                }
                OutputStreamWriter(conn.outputStream, StandardCharsets.UTF_8).use { writer ->
                    writer.write(payload)
                    writer.flush()
                }
                if (conn.responseCode in 200..299) {
                    val responseBody = BufferedReader(
                        InputStreamReader(conn.inputStream, StandardCharsets.UTF_8)
                    ).use { it.readText() }
                    val root = JSONObject(responseBody)
                    val cfg = root.optJSONObject("config")
                        ?: root.optJSONObject("result")?.optJSONObject("config")
                    if (cfg != null) {
                        val v4 = cfg.optJSONObject("interface")
                            ?.optJSONObject("addresses")
                            ?.optString("v4", "172.16.0.2")
                            ?: "172.16.0.2"
                        val peerKey = cfg.optJSONArray("peers")
                            ?.optJSONObject(0)
                            ?.optString("public_key", defaultPeerKey)
                            ?: defaultPeerKey
                        conn.disconnect()
                        return Pair(v4, peerKey)
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                Log.w(TAG, "WARP registration attempt failed on $urlStr: ${e.message}")
            }
        }
        throw IllegalStateException("Could not register WireGuard key. Check internet or paste a custom .conf.")
    }

    private fun fetchCurrentExitIpAndCountry(expectedCountry: String): String {
        // Query ipwho.is or 1.1.1.1/cdn-cgi/trace to verify the actual exit IP and Geo-IP Country
        try {
            val conn = (URL("https://ipwho.is/").openConnection() as HttpURLConnection).apply {
                connectTimeout = 4500
                readTimeout = 4500
            }
            if (conn.responseCode in 200..299) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                val ip = json.optString("ip", "")
                val country = json.optString("country", "")
                val cc = json.optString("country_code", "")
                if (ip.isNotBlank()) {
                    return if (country.isNotBlank()) "$ip • $country ($cc)" else ip
                }
            }
            conn.disconnect()
        } catch (_: Exception) {
        }

        return try {
            val conn = (URL("https://1.1.1.1/cdn-cgi/trace").openConnection() as HttpURLConnection).apply {
                connectTimeout = 4000
                readTimeout = 4000
            }
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val ipLine = text.lineSequence().firstOrNull { it.startsWith("ip=") }?.removePrefix("ip=")
            val locLine = text.lineSequence().firstOrNull { it.startsWith("loc=") }?.removePrefix("loc=")
            if (!ipLine.isNullOrBlank()) {
                "$ipLine • ${locLine ?: expectedCountry}"
            } else {
                "Masked ($expectedCountry Tunnel)"
            }
        } catch (_: Exception) {
            "Masked ($expectedCountry Tunnel)"
        }
    }

    private fun startTelemetryLoop(serverName: String) {
        telemetryJob?.cancel()
        telemetryJob = serviceScope.launch {
            val startRx = TrafficStats.getTotalRxBytes().coerceAtLeast(0L)
            val startTx = TrafficStats.getTotalTxBytes().coerceAtLeast(0L)
            var prevRx = startRx
            var prevTx = startTx
            var prevTime = System.currentTimeMillis()
            var tickCount = 0

            while (isRunning.get() && isActive) {
                delay(500L)
                val nowTime = System.currentTimeMillis()
                val elapsedSec = ((nowTime - prevTime) / 1000.0).coerceAtLeast(0.1)

                val nowRx = TrafficStats.getTotalRxBytes().coerceAtLeast(prevRx)
                val nowTx = TrafficStats.getTotalTxBytes().coerceAtLeast(prevTx)

                val rxSpeed = ((nowRx - prevRx) / elapsedSec).toLong().coerceAtLeast(0L)
                val txSpeed = ((nowTx - prevTx) / elapsedSec).toLong().coerceAtLeast(0L)
                val totalRx = (nowRx - startRx).coerceAtLeast(0L)
                val totalTx = (nowTx - startTx).coerceAtLeast(0L)

                prevRx = nowRx
                prevTx = nowTx
                prevTime = nowTime
                tickCount++

                broadcastState(
                    state = "CONNECTED",
                    rxBytes = totalRx,
                    txBytes = totalTx,
                    rxSpeed = rxSpeed,
                    txSpeed = txSpeed,
                    publicIp = currentPublicIp,
                    errorMsg = ""
                )

                if (tickCount % 2 == 0) {
                    updateNotification(
                        "$serverName • ↓ ${formatSpeedShort(rxSpeed)}  ↑ ${formatSpeedShort(txSpeed)}"
                    )
                }
            }
        }
    }

    private fun formatSpeedShort(bytesPerSec: Long): String {
        if (bytesPerSec < 1024) return "$bytesPerSec B/s"
        val kb = bytesPerSec / 1024.0
        if (kb < 1024) return String.format("%.1f KB/s", kb)
        val mb = kb / 1024.0
        return String.format("%.2f MB/s", mb)
    }

    private fun stopWireGuardTunnel() {
        isRunning.set(false)
        telemetryJob?.cancel()
        tunnelJob?.cancel()
        try {
            sharedBackend?.setState(wgTunnel, Tunnel.State.DOWN, null)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping WireGuard GoBackend", e)
        }
        broadcastState("DISCONNECTED", 0L, 0L, 0L, 0L, "Unmasked (ISP Direct)", "")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
    }

    private fun broadcastState(
        state: String,
        rxBytes: Long,
        txBytes: Long,
        rxSpeed: Long,
        txSpeed: Long,
        publicIp: String,
        errorMsg: String
    ) {
        val intent = Intent(ACTION_STATUS_BROADCAST).apply {
            setPackage(packageName)
            putExtra(EXTRA_STATE, state)
            putExtra(EXTRA_RX_BYTES, rxBytes)
            putExtra(EXTRA_TX_BYTES, txBytes)
            putExtra(EXTRA_RX_SPEED, rxSpeed)
            putExtra(EXTRA_TX_SPEED, txSpeed)
            putExtra(EXTRA_PUBLIC_IP, publicIp)
            putExtra(EXTRA_ERROR_MSG, errorMsg)
        }
        sendBroadcast(intent)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Dark VPN Country Tunnel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Displays Dark VPN active country tunnel status and live speed"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(contentText: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingOpenIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val disconnectIntent = Intent(this, FreeVpnService::class.java).apply {
            action = ACTION_DISCONNECT
        }
        val pendingDisconnectIntent = PendingIntent.getService(
            this,
            1,
            disconnectIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_dark_vpn_logo)
            .setContentTitle("Dark VPN • Country Tunnel Active")
            .setContentText(contentText)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingOpenIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Disconnect",
                pendingDisconnectIntent
            )
            .build()
    }

    private fun updateNotification(contentText: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager?.notify(NOTIFICATION_ID, buildNotification(contentText))
    }

    override fun onRevoke() {
        stopWireGuardTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopWireGuardTunnel()
        serviceScope.cancel()
        super.onDestroy()
    }
}
